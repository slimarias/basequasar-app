<template></template>
<script>
  export default {
    computed: {
      crudData() {
        return {
          apiRoute: 'apiRoutes.discountable.discounts',
          permission: 'discountable.discounts',
          extraFormFields: 'crud-fields.Discountable.discounts',
          create: {
            title: this.$tr('discountable.layout.newDiscount'),
            to: {name: 'discountable.admin.discounts.create'}
          },
          read: {
            columns: [
              {name: 'id', label: this.$tr('ui.form.id'), field: 'id', align: 'left'},
              {name: 'name', label: this.$tr('ui.form.name'), field: 'name', align: 'left'},
              {name: 'code', label: this.$tr('discountable.layout.form.code'), field: 'code', align: 'left'},
              {name: 'createdAt', label: this.$tr('ui.form.createdAt'), field: 'createdAt', align: 'left', format: val => this.$trd(val)},
              {name: 'actions', label: this.$tr('ui.form.actions'), align: 'right'},
            ],
            requestParams: {},
            filters: {},
          },
          update: {
            to : 'discountable.admin.discounts.edit'
          },
          delete: true,
          formLeft: {},
        }
      }
    }
  }
</script>
