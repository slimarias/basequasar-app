export default {
  adminGroup : 'Discounts',
  adminDiscounts: 'Discounts',
  createDiscounts: 'Create Discount',
  editDiscounts: 'Edit Discount',
}
