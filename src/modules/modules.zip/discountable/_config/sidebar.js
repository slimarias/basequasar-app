const pages = config('pages') // Get Pages from config

//E-commerce
export default [
  {
    title: 'discountable.sidebar.adminGroup',
    icon: 'fas fa-cash-register',
    children: [
      pages.discountable.discounts,
    ]
  }
]
