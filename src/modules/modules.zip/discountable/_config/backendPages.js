export default {
  discounts: {
    permission: 'discountable.discounts.index',
    activated: true,
    path: '/discounts',
    name: 'discountable.admin.discounts.index',
    page: () => import('src/modules/discountable/_pages/admin/discounts/index'),
    layout: () => import('@imagina/qsite/_layouts/master.vue'),
    title: 'discountable.sidebar.adminDiscounts',
    icon: 'fas fa-ticket-alt',
    authenticated: true,
    subHeader:{
      refresh: true,
    }
  },
  discountsCreate: {
    permission: 'discountable.discounts.create',
    activated: true,
    path: '/discounts/create',
    name: 'discountable.admin.discounts.create',
    page: () => import('src/modules/discountable/_pages/admin/discounts/form'),
    layout: () => import('@imagina/qsite/_layouts/master.vue'),
    title: 'discountable.sidebar.createDiscounts',
    icon: 'fas fa-ticket-alt',
    authenticated: true,
    subHeader:{
      breadcrumb: ['discountable.discounts']
    }
  },
  discountsEdit: {
    permission: 'discountable.discounts.edit',
    activated: true,
    path: '/discounts/:id',
    name: 'discountable.admin.discounts.edit',
    page: () => import('src/modules/discountable/_pages/admin/discounts/form'),
    layout: () => import('@imagina/qsite/_layouts/master.vue'),
    title: 'discountable.sidebar.editDiscounts',
    icon: 'fas fa-ticket-alt',
    authenticated: true,
    subHeader:{
      breadcrumb: ['discountable.discounts']
    }
  },
}
