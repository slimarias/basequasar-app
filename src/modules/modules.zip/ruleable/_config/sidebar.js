const pages = config('pages') // Get Pages from config

//E-commerce
export default [
  {
    title: 'ruleable.sidebar.adminGroup',
    icon: 'fas fa-ruler',
    children: [
      pages.ruleable.rules,
    ]
  }
]
