export default {
  rules: {
    permission: 'ruleable.rules.index',
    activated: true,
    path: '/rules',
    name: 'ruleable.admin.rules.index',
    page: () => import('src/modules/ruleable/_pages/admin/rules/index'),
    layout: () => import('@imagina/qsite/_layouts/master.vue'),
    title: 'ruleable.sidebar.adminRules',
    icon: 'fas fa-ruler',
    authenticated: true,
    subHeader:{
      refresh: true,
    }
  },
  rulesCreate: {
    permission: 'ruleable.rules.create',
    activated: true,
    path: '/rules/create',
    name: 'ruleable.admin.rules.create',
    page: () => import('src/modules/ruleable/_pages/admin/rules/form'),
    layout: () => import('@imagina/qsite/_layouts/master.vue'),
    title: 'ruleable.sidebar.createRules',
    icon: 'fas fa-ruler',
    authenticated: true,
    subHeader:{
      breadcrumb: ['ruleable.rules']
    }
  },
  rulesEdit: {
    permission: 'ruleable.rules.edit',
    activated: true,
    path: '/rules/:id',
    name: 'ruleable.admin.rules.edit',
    page: () => import('src/modules/ruleable/_pages/admin/rules/form'),
    layout: () => import('@imagina/qsite/_layouts/master.vue'),
    title: 'ruleable.sidebar.editRules',
    icon: 'fas fa-ruler',
    authenticated: true,
    subHeader:{
      breadcrumb: ['ruleable.rules'],
      refresh: true,
    }
  },
}
