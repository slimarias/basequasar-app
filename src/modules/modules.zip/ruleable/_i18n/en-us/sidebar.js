export default {
  adminGroup : 'rules',
  adminRules: 'rules',
  createRules: 'Create rule',
  editRules: 'Edit rule',
}
