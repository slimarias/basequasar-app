import layout from 'src/modules/ruleable/_i18n/en-us/layout'
import sidebar from 'src/modules/ruleable/_i18n/en-us/sidebar'

export default {
  layout,
  sidebar
}
